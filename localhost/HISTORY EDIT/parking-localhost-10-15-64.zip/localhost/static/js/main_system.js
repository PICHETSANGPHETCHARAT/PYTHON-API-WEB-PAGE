$( document ).ready(function() {
    console.log( "ready!" );
});