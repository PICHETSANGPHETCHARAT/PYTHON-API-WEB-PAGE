$(document).ready(function () {
    oneProcess();
    twoProcess();
});
// todo:--------------------------------------------------------------------------------------------------------
function oneProcess() {
    console.log("Hello 1");
}
// todo:--------------------------------------------------------------------------------------------------------
function twoProcess() {
    console.log("Hello 2");
}
// todo:--------------------------------------------------------------------------------------------------------
function getDataTime() {
    $.ajax({
        url: "http://worldtimeapi.org/api/timezone/Asia/Bangkok",
        method: "GET",
        dataType: "json",
        success: function (data) {
            console.log(data);
            var Data = "";
            Data += "<b>";
            Data += "Time: " + data["datetime"] + "&nbsp;&nbsp;&nbsp;" + "Timezone: " + data["timezone"];
            Data += "</b>";
            $("#result").html(Data);
            console.log(Data);
        },
    });
}
// todo:--------------------------------------------------------------------------------------------------------
function getDatajson() {
    // var json = `[
    // 	[
    // 	  {
    // 		"count_IN":{
    // 		  "type": "Number",
    // 		  "value": 1
    // 		}
    // 	  },
    // 	  {
    // 		"count_OUT":{
    // 		  "type": "Number",
    // 		  "value": 0
    // 		}
    // 	  }
    // 	]
    //   ]`;
    // json = JSON.parse(json);
    // console.log(json);
    // var Data = "";
    // var count_IN = "";
    // var count_OUT = "";
    // // ! Print test ==============================
    // for (var i = 0; i < json[0].length; i++) {
    //     console.log(json[0][i]);
    // }
    // // ! =========================================
    // for (var i = 0; i < json[0].length; i++) {
    // 	if (i == 0) {
    // 		count_IN = json[0][i]["count_IN"]["value"];
    // 	}
    // 	else if(i == 1){
    // 		count_OUT = json[0][i]["count_OUT"]["value"];
    // 	}

    // }
    // console.log(count_IN);
    // console.log(count_OUT);
    // Data += "<b>";
    // Data += "IN: " + count_IN + "&nbsp;&nbsp;&nbsp;" + "OUT: " + count_OUT;
    // Data += "</b>";
    // $("#result").html(Data);
    // console.log(Data);

    // !!! ================================================================================
    var json = `{
		"type": "cctv",
		"id": "Camrea_id:B12F04N15",
		"building": { "value": "12", "type": "Text" },
		"floor": { "value": "04", "type": "Text" },
		"currentTime": { "value": "2021-06-21 10:56:27", "type": "Datetime" },
		"event": { "value": "IN", "type": "Text" },
		"image": { "value": "/parking/B12/F04/2021-06-21/images/B12F04N15_20210621_105627074.jpg", "type": "Text" },
		"position": { "value": "/parking/B12/F04/2021-06-21/position/B12F04N15_20210621_105627074.json", "type": "Text" },
		"count_IN": { "value": 1, "type": "Number" },
		"count_OUT": { "value": 0, "type": "Number" },
		"restartTime": { "value": "2021-06-21 10:55:58.777834", "type": "Datetime" }
	}`;
    json = JSON.parse(json);
    console.log(json);
    var Data = "";
    var count_IN = json["count_IN"]["value"];
    var count_OUT = json["count_OUT"]["value"];

    console.log(count_IN);
    console.log(count_OUT);
    Data += "<b>";
    Data += "IN: " + count_IN + "&nbsp;&nbsp;&nbsp;" + "OUT: " + count_OUT;
    Data += "</b>";
    $("#result").html(Data);
    console.log(Data);
}
// todo:--------------------------------------------------------------------------------------------------------
// function testPost(ID) {
// 	$.ajax({
// 		url: "localhost:3000/testpost",
// 		method: "POST",
// 		datatype: "json",
// 		data: {
// 			ID_BUY: ID
// 		},
// 		success: function (data) {
// 			getData_Buy();
// 		}
// 	});
// }
