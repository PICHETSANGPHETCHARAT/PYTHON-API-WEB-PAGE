#ฟั่งชั่นบันทึกไฟล์ยังไม่สมบูรณ์
cursor = ใส่คอลเล็คชั่นที่ต้องการ[yom7dข้อมูลเช่น-mycol.find()
mongo_docs = list(cursor)
mongo_docs = mongo_docs[:1] # slice the list
print ("total docs:", len(mongo_docs))
docs = pandas.DataFrame(columns=[])
for num, doc in enumerate(mongo_docs):
    doc["_id"] = str(doc["_id"])
    doc_id = doc["_id"]
series_obj = pandas.Series( doc, name=doc_id )
docs = docs.append(series_obj)
json_export = docs.to_json() # return JSON data
print ("\nJSON data:", json_export)
docs.to_json("dataupdate.json")




#ฟังชั่นบันทึกข้อมูลชุดที่1ลงใน MongoDB
@app.route('/insert1',methods=['POST'])
def insert1():
    if request.method=='POST':
        number=request.form['number']       
        type=request.form['type']
        building=request.form['building'] 
        floor=request.form['floor'] 
        event=request.form['event'] 
        sensor=request.form['sensor']
        pixel=request.form['pixel'] 
        framerate=request.form['framerate'] 
        light=request.form['light'] 
        daynight=request.form['daynight']
        lens=request.form['lens']
        ir=request.form['ir']
        
          
        ใส่คอลเล็คชั่นที่ต้องการเก็บข้อมูลเช่น-mycol.insert({'หมายเลขกล้อง' : request.form.get('number'),'รุ่น' : request.form.get('type'),'ตึกที่ติดตั้ง' : request.form.get('building'),'ชั้นที่ติดตั้ง' : request.form.get('floor')
        ,'หน้าที่' : request.form.get('event'),'เซนเซอร์รับภาพ' : request.form.get('sensor'),'จำนวนพิกเซล' : request.form.get('pixel'),'Frame Rate' : request.form.get('framerate')
        ,'แสงต่ำสุดที่รับภาพได้' : request.form.get('light'),'ระบบ Day/Night' : request.form.get('daynight'),'เลนส์' : request.form.get('lens'),'ระยะIRไกลสุด' : request.form.get('ir')})  
    return redirect(url_for("adddevice2")) 





#ฟังชั่นบันทึกข้อมูลชุดที่2ลงใน MongoDB
@app.route('/insert2',methods=['POST'])
def insert2():
    if request.method=='POST':
        floor=request.form['floor']       
        number=request.form['number']
        apirealtime=request.form['apirealtime'] 
        apihistory=request.form['apihistory'] 
        apidevice=request.form['apidevice'] 
        apiinfo=request.form['apiinfo'] 
        user=request.form['user']  
        password=request.form['password']      
          
        ใส่คอลเล็คชั่นที่ต้องการเก็บข้อมูลเช่น-mycol.insert({'Floor' : request.form.get('floor'),'ID Number' : request.form.get('number'),'Api Realtime' : request.form.get('apirealtime'),'Api History' : request.form.get('apihistory')
        ,'Api Device' : request.form.get('apidevice'),'Api Info' : request.form.get('apiinfo'),'User' : request.form.get('user'),'Password' : request.form.get('password')})  

    return redirect(url_for("devicenew")) 