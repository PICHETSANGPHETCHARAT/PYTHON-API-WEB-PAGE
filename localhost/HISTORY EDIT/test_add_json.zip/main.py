from flask import Flask
from pymongo import MongoClient
from bson import Binary, Code
from bson.json_util import dumps
import json
# !-------------------------------------
app = Flask(__name__)
client = MongoClient()
client = MongoClient('localhost', 27017)
db = client['test_json']
collection = db['json']
# !-------------------------------------
post = open('B12F04N13_20210621_131558344.json',)
result_json = json.load(post)
# print (result_json)
# !-------------------------------------
@app.route("/")
def hello():
    return "<!--<a href='http://localhost:5000/add_json'> <button><h2>Add </h2></button> </a>-->  <a href='http://localhost:5000/get'> <button><h2>Show </h2></button> </a>"
# !-------------------------------------
# @app.route("/add_json")
# def add():
#     # print (result_json)
#     # add_json_mongo = collection.insert(loads(result_json))
#     add_json_mongo = collection.insert(dumps(result_json))
#     return ("Submit")
# !-------------------------------------
# @app.route("/get")
# def get():
#     text = ""
#     result_date = collection.find({})
#     for document in result_date:
#         print(document)
#         text += str(document)
#     result_json = json.dumps(text)
#     return (result_json)
# !-------------------------------------
@app.route("/get")
def get():
    result_date = collection.find_one()
    return (parse_json(result_date))
# todo: ------------------
def parse_json(data):
    return json.loads(dumps(data))
# !-------------------------------------
if __name__ == "__main__":
    app.run(debug=True)